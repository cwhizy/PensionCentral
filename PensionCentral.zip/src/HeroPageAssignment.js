import styles from "./css/HeroPageAssignment.module.css";

export const HeroPageAssignment = () => {
  return (
    <div className={styles.heroPageAssignment}>
      <img className={styles.vector7} alt="" src="/vector.svg" />
      <div className={styles.background} />
      <img className={styles.dotsWorld} alt="" src="/dots-world.svg" />
      <img className={styles.vector6} alt="" src="/vector1.svg" />
      <img className={styles.vector5} alt="" src="/vector2.svg" />
      <img className={styles.vector4} alt="" src="/vector3.svg" />
      <img className={styles.vectorIcon} alt="" src="/vector4.svg" />
      <img className={styles.vector3} alt="" src="/vector5.svg" />
      <img className={styles.vector2} alt="" src="/vector6.svg" />
      <img className={styles.vector1} alt="" src="/vector7.svg" />
      <img className={styles.vector} alt="" src="/vector8.svg" />
      <img className={styles.navBase} alt="" src="/nav-base.svg" />
      <img
        className={styles.pensionCentralLogo011}
        alt=""
        src="/pension-central-logo-01-1@2x.png"
      />
      <div className={styles.loginContainer}>
        <div className={styles.rectangleRectangle1} />
        <div className={styles.loginText}>Login</div>
      </div>
      <div className={styles.rectangleRectangle} />
      <b className={styles.createAccountText}>Create Account</b>
      <div className={styles.groupContainer1}>
        <div className={styles.productText}>Product</div>
        <img
          className={styles.iconChevronBottom2}
          alt=""
          src="/iconchevron-bottom.svg"
        />
      </div>
      <div className={styles.groupContainer}>
        <img
          className={styles.iconChevronBottom1}
          alt=""
          src="/iconchevron-bottom1.svg"
        />
        <div className={styles.companyText}>Company</div>
      </div>
      <div className={styles.developersText}>Developers</div>
      <div className={styles.helpContainer}>
        <img
          className={styles.iconChevronBottom}
          alt=""
          src="/iconchevron-bottom2.svg"
        />
        <div className={styles.helpText}>Help</div>
      </div>
      <div className={styles.pricingText}>Pricing</div>
      <img className={styles.dotsAfrica} alt="" src="/dots-africa.svg" />
      <img className={styles.heroWomanImage} alt="" src="/hero-woman@2x.png" />
    </div>
  );
};
